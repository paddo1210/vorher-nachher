export type PhotoKind = "before" | "after";
export interface JobPhoto { id: string; kind: PhotoKind; dataUrl: string; note: string; createdAt: string; pairId?: string; }
export type JobStatus = "Neu" | "Vorher dokumentiert" | "In Arbeit" | "Abgeschlossen";
export interface Job { id: string; customer: string; project: string; address: string; description: string; date: string; hours: string; finalNote: string; status: JobStatus; photos: JobPhoto[]; createdAt: string; updatedAt: string; }
