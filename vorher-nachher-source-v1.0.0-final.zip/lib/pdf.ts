import type { Job, JobPhoto } from "./types";

const safe = (value: string, fallback = "–") => value.trim() || fallback;
async function imageSize(src: string): Promise<{ width: number; height: number }> { return new Promise((resolve) => { const image = new Image(); image.onload = () => resolve({ width: image.width, height: image.height }); image.onerror = () => resolve({ width: 4, height: 3 }); image.src = src; }); }
const photoFormat = (photo: JobPhoto) => photo.dataUrl.startsWith("data:image/png") ? "PNG" : "JPEG";

export async function createJobPdf(job: Job): Promise<Blob> {
  const { jsPDF } = await import("jspdf");
  const pdf = new jsPDF({ unit: "mm", format: "a4" });
  const margin = 15; let y = 18;
  const pageCheck = (needed: number) => { if (y + needed > 282) { pdf.addPage(); y = 18; } };
  const line = (label: string, value: string) => { pageCheck(8); pdf.setFont("helvetica", "bold"); pdf.text(label, margin, y); pdf.setFont("helvetica", "normal"); pdf.text(safe(value), margin + 35, y); y += 7; };
  pdf.setFillColor(9, 12, 16); pdf.rect(0, 0, 210, 36, "F"); pdf.setTextColor(244, 248, 251); pdf.setFontSize(22); pdf.setFont("helvetica", "bold"); pdf.text("VORHER VS NACHHER", margin, 22);
  pdf.setTextColor(30); pdf.setFontSize(10); y = 47; line("Kunde", job.customer); line("Projekt", job.project); line("Adresse", job.address); line("Datum", new Date(job.date + "T12:00:00").toLocaleDateString("de-DE")); line("Arbeitszeit", job.hours ? `${job.hours} Stunden` : "–");
  if (job.description) { pageCheck(18); pdf.setFont("helvetica", "bold"); pdf.text("Ausgangszustand", margin, y); y += 6; pdf.setFont("helvetica", "normal"); const lines = pdf.splitTextToSize(job.description, 180); pdf.text(lines, margin, y); y += lines.length * 5 + 4; }
  const before = job.photos.filter((p) => p.kind === "before"), after = job.photos.filter((p) => p.kind === "after");
  const pairs: { before?: JobPhoto; after?: JobPhoto }[] = before.map((photo, index) => ({ before: photo, after: after.find((item) => item.id === photo.pairId) ?? after[index] }));
  after.filter((photo) => !pairs.some((pair) => pair.after?.id === photo.id)).forEach((photo) => pairs.push({ after: photo }));
  pageCheck(12); pdf.setFontSize(15); pdf.setFont("helvetica", "bold"); pdf.text("Vorher / Nachher", margin, y); y += 9;
  for (const pair of pairs) { pageCheck(72); for (const [index, photo] of [pair.before, pair.after].entries()) { const x = margin + index * 92; pdf.setFontSize(9); pdf.setFont("helvetica", "bold"); pdf.setTextColor(index === 0 ? 80 : 45, index === 0 ? 130 : 160, index === 0 ? 175 : 125); pdf.text(index === 0 ? "VORHER" : "NACHHER", x, y); if (photo) { const size = await imageSize(photo.dataUrl), ratio = Math.min(84 / size.width, 48 / size.height), w = size.width * ratio, h = size.height * ratio; pdf.addImage(photo.dataUrl, photoFormat(photo), x, y + 3, w, h, undefined, "FAST"); pdf.setTextColor(70); pdf.setFont("helvetica", "normal"); pdf.setFontSize(7.5); const note = safe(photo.note, new Date(photo.createdAt).toLocaleString("de-DE")); pdf.text(pdf.splitTextToSize(note, 84), x, y + 56); } else { pdf.setTextColor(140); pdf.setFont("helvetica", "normal"); pdf.text("Kein Foto", x, y + 18); } } y += 68; }
  if (job.finalNote) { pageCheck(28); pdf.setTextColor(30); pdf.setFontSize(13); pdf.setFont("helvetica", "bold"); pdf.text("Durchgeführte Arbeit", margin, y); y += 7; pdf.setFontSize(10); pdf.setFont("helvetica", "normal"); pdf.text(pdf.splitTextToSize(job.finalNote, 180), margin, y); }
  const pages = pdf.getNumberOfPages(); for (let i = 1; i <= pages; i++) { pdf.setPage(i); pdf.setTextColor(120); pdf.setFontSize(8); pdf.text(`Erstellt mit Vorher VS Nachher · Seite ${i}/${pages}`, margin, 291); }
  return pdf.output("blob");
}

export async function createWorkReportPdf(jobs: Job[], options: { includePhotos: boolean; period: string }): Promise<Blob> {
  const { jsPDF } = await import("jspdf");
  const pdf = new jsPDF({ unit: "mm", format: "a4" });
  const margin = 15;
  let y = 18;
  const totalHours = jobs.reduce((sum, job) => sum + (Number(job.hours.replace(",", ".")) || 0), 0);
  const workdays = new Set(jobs.map((job) => job.date)).size;
  const pageCheck = (needed: number) => { if (y + needed > 280) { pdf.addPage(); y = 18; } };
  pdf.setFillColor(9, 12, 16); pdf.rect(0, 0, 210, 34, "F");
  pdf.setTextColor(244, 248, 251); pdf.setFontSize(20); pdf.setFont("helvetica", "bold"); pdf.text("ARBEITSNACHWEIS", margin, 21); y = 44;
  pdf.setTextColor(30); pdf.setFontSize(11); pdf.text(options.period, margin, y); y += 8;
  pdf.setFontSize(9); pdf.setFont("helvetica", "normal"); pdf.setTextColor(80);
  pdf.text(`${workdays} Arbeitstage  ·  ${jobs.length} Aufträge  ·  ${totalHours.toLocaleString("de-DE", { maximumFractionDigits: 2 })} Stunden`, margin, y); y += 12;
  for (const job of jobs) {
    const before = job.photos.find((photo) => photo.kind === "before");
    const after = job.photos.find((photo) => photo.kind === "after");
    const photoHeight = options.includePhotos && (before || after) ? 54 : 0;
    pageCheck(30 + photoHeight);
    pdf.setDrawColor(220); pdf.line(margin, y, 195, y); y += 6;
    pdf.setTextColor(30); pdf.setFontSize(10); pdf.setFont("helvetica", "bold");
    pdf.text(new Date(job.date + "T12:00:00").toLocaleDateString("de-DE"), margin, y);
    pdf.text(job.hours ? `${job.hours.replace(".", ",")} Std.` : "– Std.", 195, y, { align: "right" }); y += 6;
    pdf.text(safe(job.customer, "Ohne Kundenangabe"), margin, y); y += 5;
    pdf.setFont("helvetica", "normal"); pdf.setFontSize(9); pdf.setTextColor(70);
    const task = safe(job.project || job.finalNote, "Keine Tätigkeitsangabe");
    const taskLines = pdf.splitTextToSize(task, 180).slice(0, 3); pdf.text(taskLines, margin, y); y += taskLines.length * 4.5;
    if (job.address) { pdf.setTextColor(110); pdf.text(job.address, margin, y); y += 5; }
    if (options.includePhotos && (before || after)) {
      y += 2;
      for (const [index, photo] of [before, after].entries()) {
        const x = margin + index * 92;
        pdf.setFont("helvetica", "bold"); pdf.setFontSize(7.5);
        pdf.setTextColor(index === 0 ? 80 : 45, index === 0 ? 130 : 160, index === 0 ? 175 : 125);
        pdf.text(index === 0 ? "VORHER" : "NACHHER", x, y);
        if (photo) {
          const size = await imageSize(photo.dataUrl), ratio = Math.min(84 / size.width, 42 / size.height), w = size.width * ratio, h = size.height * ratio;
          pdf.addImage(photo.dataUrl, photoFormat(photo), x, y + 3, w, h, undefined, "FAST");
        }
      }
      y += 49;
    }
    y += 3;
  }
  const pages = pdf.getNumberOfPages();
  for (let i = 1; i <= pages; i++) { pdf.setPage(i); pdf.setTextColor(120); pdf.setFontSize(8); pdf.text(`Vorher VS Nachher · Arbeitsnachweis · Seite ${i}/${pages}`, margin, 291); }
  return pdf.output("blob");
}
